from django_unicorn.components import UnicornView


class SidebarMenuView(UnicornView):
    pass
